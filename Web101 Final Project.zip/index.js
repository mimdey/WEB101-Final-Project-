/*** Dark Mode ***/
let themeButton = document.getElementById("theme-button");

const toggleDarkMode = () => {
  document.body.classList.toggle("dark-mode");
};

themeButton.addEventListener("click", toggleDarkMode);

/*** RSVP State Management ***/
let count = 3;
const rsvpButton = document.getElementById("rsvp-button");
const participantsList = []; // Optional: stores RSVP objects

/*** Add Participant Function ***/
const addParticipant = (person) => {
  participantsList.push(person); // Save person to list

  const newParticipant = document.createElement("p");
  newParticipant.textContent = `🎀 ${person.name} is going!! Favorite 2000s Jam: "${person.song}"`;

  const participantsDiv = document.querySelector(".participants");
  participantsDiv.appendChild(newParticipant);

  count++;

  const rsvpCountElement = document.getElementById("rsvp-count");
  rsvpCountElement.textContent = `⭐ ${count} people have RSVP'd to this event!`;
};

/*** Validate Form and Create Person Object ***/
const validateForm = (event) => {
  event.preventDefault();

  let containsErrors = false;
  let rsvpInputs = document.getElementById("rsvp-form").elements;

  // Create the person object
  const person = {
    name: document.getElementById("name").value.trim(),
    email: document.getElementById("email").value.trim(),
    song: document.getElementById("song").value.trim()
  };

  // Loop to check for empty inputs (excluding the button)
  for (let i = 0; i < rsvpInputs.length; i++) {
    let input = rsvpInputs[i];
    if (input.type === "button") continue;

    if (input.value.trim().length < 2) {
      containsErrors = true;
      input.classList.add("error");
    } else {
      input.classList.remove("error");
    }
  }

  // Specific Email Validation
  const emailInput = document.getElementById("email");
  const emailError = document.getElementById("email-error");

  if (person.email !== "" && (!person.email.includes("@") || !person.email.endsWith(".com"))) {
    containsErrors = true;
    emailInput.classList.add("error");
    emailError.style.display = "block";
  } else {
    emailInput.classList.remove("error");
    emailError.style.display = "none";
  }

  // If no errors, submit the form
  if (!containsErrors) {
    addParticipant(person);
    toggleModal(person);
    document.getElementById("rsvp-form").reset();
  }
};

rsvpButton.addEventListener("click", validateForm);

/*** Animations [PLACEHOLDER] [ADDED IN UNIT 8] ***/
/*** Modal ***
  
  Purpose:
  - Use this starter code to add a pop-up modal to your website.

  When To Modify:
  - [ ] Project 9 (REQUIRED FEATURE)
  - [ ] Project 9 (STRETCH FEATURE)
  - [ ] Any time after
***/
let intervalId; // now this can be used in both toggleModal() and closeModal()


const toggleModal = (person) => {
  const modal = document.getElementById("success-modal");
  const modalText = document.getElementById("modal-text");
  
  // TODO: Update modal display to flex
  modal.style.display = "flex";

  // TODO: Update modal text to personalized message
  modalText.textContent = `💿 Thanks for RSVPing, ${person.name}! Get ready to party like it's 2004 at the ultimate Y2K bash! 💖 See you on the dance floor! 🪩✨`;

// Start bounce animation
  intervalId = setInterval(animateImage, 30);
  // Set modal timeout to 5 seconds
  setTimeout(() => {
    modal.style.display = "none";
    clearInterval(intervalId);
    modalImage.style.transform = "translateY(0px)";
  }, 5000);
};


// TODO: animation variables and animateImage() function
let bounceDirection = 1;
let bouncePosition = 0;
const modalImage = document.querySelector("#success-modal img");

const animateImage = () => {
  if (bouncePosition <= -20) bounceDirection = 1;
  else if (bouncePosition >= 0) bounceDirection = -1;

  bouncePosition += bounceDirection * 2;
  modalImage.style.transform = `translateY(${bouncePosition}px)`;
};
// Close button for modal
const closeModalButton = document.getElementById("close-modal-button");

const closeModal = () => {
  const modal = document.getElementById("success-modal");
  modal.style.display = "none";

  // Also stop animation
  clearInterval(intervalId);
  modalImage.style.transform = "translateY(0px)";
};

// Add click event
closeModalButton.addEventListener("click", closeModal);
